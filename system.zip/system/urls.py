from django.contrib import admin
from django.urls import path, include 

from django.conf.urls.static import static  
from django.conf import settings  

urlpatterns = [
    path('admin/', admin.site.urls),

    # My urls 
    path('', include('home.urls')), 
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)

admin.AdminSite.site_header = 'Institucional Yorus GTO'
admin.AdminSite.site_title = 'Institucional Yorus GTO'
admin.AdminSite.index_title = 'Institucional Yorus GTO'